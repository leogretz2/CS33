/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_431()
{
    return 2425393272U;
}

void setval_375(unsigned *p)
{
    *p = 3281016919U;
}

unsigned getval_274()
{
    return 3284633928U;
}

void setval_495(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_462()
{
    return 3281293400U;
}

void setval_190(unsigned *p)
{
    *p = 3284633944U;
}

void setval_105(unsigned *p)
{
    *p = 3284601160U;
}

unsigned addval_181(unsigned x)
{
    return x + 2425379038U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_391(unsigned *p)
{
    *p = 3225993609U;
}

unsigned addval_425(unsigned x)
{
    return x + 3676883593U;
}

void setval_167(unsigned *p)
{
    *p = 3183985033U;
}

unsigned addval_351(unsigned x)
{
    return x + 2425405833U;
}

unsigned addval_485(unsigned x)
{
    return x + 3398038249U;
}

unsigned addval_397(unsigned x)
{
    return x + 2463533439U;
}

unsigned getval_155()
{
    return 3531921033U;
}

unsigned addval_326(unsigned x)
{
    return x + 3674784009U;
}

unsigned getval_494()
{
    return 2445969771U;
}

unsigned addval_324(unsigned x)
{
    return x + 2445379889U;
}

unsigned getval_281()
{
    return 3380136585U;
}

unsigned getval_482()
{
    return 3380920713U;
}

void setval_409(unsigned *p)
{
    *p = 3351349548U;
}

unsigned getval_475()
{
    return 2430634312U;
}

void setval_267(unsigned *p)
{
    *p = 3286272360U;
}

void setval_423(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_134()
{
    return 3524843145U;
}

unsigned addval_349(unsigned x)
{
    return x + 3769190485U;
}

unsigned getval_459()
{
    return 3372796553U;
}

void setval_177(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_374()
{
    return 3223377577U;
}

void setval_153(unsigned *p)
{
    *p = 3677932171U;
}

unsigned getval_101()
{
    return 3871594137U;
}

void setval_315(unsigned *p)
{
    *p = 3264272009U;
}

unsigned getval_458()
{
    return 2497743176U;
}

unsigned getval_467()
{
    return 3526937289U;
}

unsigned addval_412(unsigned x)
{
    return x + 3223901833U;
}

unsigned getval_295()
{
    return 3531921033U;
}

void setval_219(unsigned *p)
{
    *p = 3687107209U;
}

unsigned addval_142(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_384(unsigned x)
{
    return x + 3223372171U;
}

void setval_308(unsigned *p)
{
    *p = 3758704681U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
